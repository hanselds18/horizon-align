using UnityEngine;
using UnityEditor;

[InitializeOnLoad]
public class LineDrawerEditor : Editor
{
    static LineDrawerEditor()
    {
        // Draw line, filled dots, and add a directional light
        DrawLineAndDotsFromFile("coordinate.txt");
        AddDirectionalLight();
    }

    static void DrawLineAndDotsFromFile(string filePath)
    {
        // Read the coordinates from the file
        string coordinatesFilePath = Application.dataPath + "/" + filePath;
        string[] lines = System.IO.File.ReadAllLines(coordinatesFilePath);

        // Create a new game object for the line renderer
        GameObject lineRendererObj = new GameObject("LineRenderer");

        // Add LineRenderer component to the game object
        LineRenderer lineRenderer = lineRendererObj.AddComponent<LineRenderer>();

        // Create an array to store the parsed coordinates
        Vector3[] coordinates = new Vector3[lines.Length];

        // Parse the coordinates from each line in the file
        for (int i = 0; i < lines.Length; i++)
        {
            string[] coords = lines[i].Split(' ');
            float x = float.Parse(coords[0]);
            float y = float.Parse(coords[1]);
            coordinates[i] = new Vector3(x, y, 0f);

            // Create a dot game object for each coordinate
            GameObject dot = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            dot.transform.position = coordinates[i];
            dot.transform.localScale = Vector3.one * 5f;

            // Set the dot material to a filled bright yellow color material
            Material dotMaterial = new Material(Shader.Find("Standard"));
            dotMaterial.color = new Color(1f, 0.92f, 0.016f);
            dot.GetComponent<Renderer>().sharedMaterial = dotMaterial;
        }

        // Set the positions of the line renderer
        lineRenderer.positionCount = coordinates.Length;
        lineRenderer.SetPositions(coordinates);

        // Set the width of the line renderer
        lineRenderer.startWidth = 0.1f;
        lineRenderer.endWidth = 0.1f;

        // Apply a road material to the line renderer
        Material roadMaterial = AssetDatabase.LoadAssetAtPath<Material>("Assets/Your/Road/Material.mat");
        lineRenderer.material = roadMaterial;
    }

    static void AddDirectionalLight()
    {
        // Create a new game object for the directional light
        GameObject directionalLightObj = new GameObject("DirectionalLight");

        // Add a directional light component to the game object
        Light directionalLight = directionalLightObj.AddComponent<Light>();

        // Set the light type to directional
        directionalLight.type = LightType.Directional;

        // Set the light color to white
        directionalLight.color = Color.white;

        // Set the light intensity
        directionalLight.intensity = 1f;

        // Set the light rotation
        directionalLight.transform.rotation = Quaternion.Euler(45f, 45f, 0f);
    }
}