using UnityEngine;
using UnityEditor;

[InitializeOnLoad]
public class PILineDrawerEditor : Editor
{
    private const float TextYPosition = 5f;
    private const float TextCharacterSize = 5f;

    static PILineDrawerEditor()
    {
        // Draw line, filled dots, apply road material, and add text
        DrawLineAndDotsFromFile("coordinate_pi.txt");
    }

    static void DrawLineAndDotsFromFile(string filePath)
    {
        // Read the coordinates from the file
        string coordinatesFilePath = Application.dataPath + "/" + filePath;
        string[] lines = System.IO.File.ReadAllLines(coordinatesFilePath);

        // Create a new game object for the line renderer
        GameObject lineRendererObj = new GameObject("PILineRenderer");

        // Add LineRenderer component to the game object
        LineRenderer lineRenderer = lineRendererObj.AddComponent<LineRenderer>();

        // Create an array to store the parsed coordinates
        Vector3[] coordinates = new Vector3[lines.Length];

        // Parse the coordinates from each line in the file
        for (int i = 0; i < lines.Length; i++)
        {
            string[] coords = lines[i].Split(' ');
            float x = float.Parse(coords[0]);
            float y = float.Parse(coords[1]);
            coordinates[i] = new Vector3(x, y, 0f);

            // Create a dot game object for each coordinate
            GameObject dot = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            dot.transform.position = coordinates[i];
            dot.transform.localScale = Vector3.one * 5f;

            // Set the dot material to a filled bright green color material
            Material dotMaterial = new Material(Shader.Find("Standard"));
            dotMaterial.color = Color.green;
            dot.GetComponent<Renderer>().sharedMaterial = dotMaterial;

            // Add text to the dot game object
            GameObject textObj = new GameObject("Text");
            textObj.transform.SetParent(dot.transform);
            textObj.transform.localPosition = new Vector3(0f, TextYPosition, 0f);

            // Add TextMesh component to the text game object
            TextMesh textMesh = textObj.AddComponent<TextMesh>();

            // Set the text based on the iterative number
            if (i == 0)
            {
                textMesh.text = "Start";
            }
            else if (i == lines.Length - 1)
            {
                textMesh.text = "End";
            }
            else
            {
                textMesh.text = "PI-" + i;
            }

            textMesh.characterSize = TextCharacterSize;
            textMesh.fontSize = 50;
            textMesh.anchor = TextAnchor.MiddleCenter;
            textMesh.alignment = TextAlignment.Center;
            textMesh.color = Color.red;
        }

        // Set the positions of the line renderer
        lineRenderer.positionCount = coordinates.Length;
        lineRenderer.SetPositions(coordinates);

        // Set the width of the line renderer
        lineRenderer.startWidth = 0.1f;
        lineRenderer.endWidth = 0.1f;

        // Apply a road material to the line renderer
        Material roadMaterial = AssetDatabase.LoadAssetAtPath<Material>("Assets/Your/Road/Material.mat");
        lineRenderer.material = roadMaterial;

        // Make the line renderer and dots visible in the Scene view
        lineRendererObj.hideFlags = HideFlags.None;
    }
}